Shader "P5UI/BlendShape"
{
    // Persona 5 메뉴 효과 재현용 UI 셰이더
    // - 하드웨어 블렌드(BlendOp/Blend)로 mix-blend-mode: screen / darken / multiply 근사
    // - 프래그먼트 단계에서 세피아 톤 + 채도 조절 (CSS filter: sepia() saturate() 대응)
    // - 버텍스 단계에서 skew + wobble 왜곡 (CSS @keyframes jelly 대응)
    //
    // 사용법: 같은 셰이더로 머티리얼을 여러 개 만들고 Blend Op / Src / Dst 값만
    // 바꿔서 Screen용, Darken용 머티리얼을 각각 준비하세요. (테스트 스크립트가 자동 생성함)

    Properties
    {
        [PerRendererData] _MainTex ("Texture", 2D) = "white" {}
        _Color ("Tint Color", Color) = (1,1,1,1)

        [Header(Blend Mode - see README for presets)]
        [Enum(UnityEngine.Rendering.BlendOp)] _BlendOp ("Blend Op", Float) = 0
        [Enum(UnityEngine.Rendering.BlendMode)] _SrcBlend ("Src Blend", Float) = 5
        [Enum(UnityEngine.Rendering.BlendMode)] _DstBlend ("Dst Blend", Float) = 10

        [Header(Color Grade - CSS filter sepia + saturate 대응)]
        _SepiaAmount ("Sepia Amount (0-1)", Range(0,1)) = 0.5
        _Saturation ("Saturation (1=normal, 3=CSS saturate(3))", Range(0,5)) = 1

        [Header(Jelly Distortion - CSS keyframes jelly 대응)]
        _JellyOn ("Jelly Enabled", Range(0,1)) = 1
        _JellySpeed ("Jelly Speed", Range(0,10)) = 2
        _SkewAmount ("Skew Amount", Range(0,40)) = 20
        _WobbleAmount ("Vertical Wobble (px)", Range(0,20)) = 4

        [Header(UI Masking - RectMask2D 호환용, 건드리지 마세요)]
        _StencilComp ("Stencil Comparison", Float) = 8
        _Stencil ("Stencil ID", Float) = 0
        _StencilOp ("Stencil Operation", Float) = 0
        _StencilWriteMask ("Stencil Write Mask", Float) = 255
        _StencilReadMask ("Stencil Read Mask", Float) = 255
        _ColorMask ("Color Mask", Float) = 15
    }

    SubShader
    {
        Tags
        {
            "Queue"="Transparent"
            "IgnoreProjector"="True"
            "RenderType"="Transparent"
            "PreviewType"="Plane"
            "CanUseSpriteAtlas"="True"
        }

        Stencil
        {
            Ref [_Stencil]
            Comp [_StencilComp]
            Pass [_StencilOp]
            ReadMask [_StencilReadMask]
            WriteMask [_StencilWriteMask]
        }

        Cull Off
        Lighting Off
        ZWrite Off
        ZTest [unity_GUIZTestMode]
        ColorMask [_ColorMask]

        BlendOp [_BlendOp]
        Blend [_SrcBlend] [_DstBlend]

        Pass
        {
            Name "Default"
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 2.0
            #pragma multi_compile_local _ UNITY_UI_CLIP_RECT
            #pragma multi_compile_local _ UNITY_UI_ALPHACLIP

            #include "UnityCG.cginc"
            #include "UnityUI.cginc"

            struct appdata_t
            {
                float4 vertex   : POSITION;
                float4 color    : COLOR;
                float2 texcoord : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct v2f
            {
                float4 vertex        : SV_POSITION;
                fixed4 color         : COLOR;
                float2 texcoord      : TEXCOORD0;
                float4 worldPosition : TEXCOORD1;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            sampler2D _MainTex;
            fixed4 _Color;
            fixed4 _TextureSampleAdd;
            float4 _ClipRect;
            float4 _MainTex_ST;

            float _SepiaAmount;
            float _Saturation;
            float _JellyOn;
            float _JellySpeed;
            float _SkewAmount;
            float _WobbleAmount;

            v2f vert(appdata_t v)
            {
                v2f OUT;
                UNITY_SETUP_INSTANCE_ID(v);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(OUT);

                float4 vertex = v.vertex;

                if (_JellyOn > 0.5)
                {
                    float t = _Time.y * _JellySpeed;
                    // skewX 근사: y 위치에 비례해서 x를 좌우로 흔듦
                    float skew = sin(t) * (_SkewAmount * 0.01);
                    vertex.x += vertex.y * skew;
                    // 젤리처럼 출렁이는 세로 wobble, x 위치마다 위상차를 줘서 뒤틀림 느낌 추가
                    vertex.y += sin(t * 2.0 + vertex.x * 0.05) * (_WobbleAmount * 0.5);
                }

                OUT.worldPosition = vertex;
                OUT.vertex = UnityObjectToClipPos(OUT.worldPosition);

                OUT.texcoord = TRANSFORM_TEX(v.texcoord, _MainTex);
                OUT.color = v.color * _Color;
                return OUT;
            }

            fixed4 frag(v2f IN) : SV_Target
            {
                half4 texCol = (tex2D(_MainTex, IN.texcoord) + _TextureSampleAdd) * IN.color;

                // 채도 조절 (CSS saturate())
                half gray = dot(texCol.rgb, half3(0.299, 0.587, 0.114));
                texCol.rgb = lerp(gray.xxx, texCol.rgb, _Saturation);

                // 세피아 톤 (CSS sepia())
                half3 sepia = half3(gray * 1.2, gray * 1.0, gray * 0.8);
                texCol.rgb = lerp(texCol.rgb, sepia, _SepiaAmount);

                #ifdef UNITY_UI_CLIP_RECT
                texCol.a *= UnityGet2DClipping(IN.worldPosition.xy, _ClipRect);
                #endif

                #ifdef UNITY_UI_ALPHACLIP
                clip (texCol.a - 0.001);
                #endif

                return texCol;
            }
            ENDCG
        }
    }
}
