using UnityEngine;
using UnityEngine.UI;

// 이 컴포넌트를 빈 GameObject에 붙이면(ExecuteAlways) Play 모드로 들어가지 않아도
// Scene 뷰에서 바로 Persona 5 스타일 블렌드/세피아/젤리 효과를 확인할 수 있습니다.
//
// 사용법:
// 1. 빈 GameObject 생성 (예: "P5_TestRig")
// 2. 이 스크립트를 붙임
// 3. Inspector의 Blend Shape Shader 필드에 P5UI/BlendShape 셰이더를 드래그 (비워두면 자동 탐색)
// 4. Scene 뷰 상단 툴바에서 "Animated Materials" 토글을 켜면 Play 없이도 애니메이션이 보입니다.
// 5. 값을 바꾸고 싶으면 Context Menu(우클릭 or ⋮) → "Rebuild Test Scene" 실행
[ExecuteAlways]
public class P5MenuTestSetup : MonoBehaviour
{
    [Header("필수: P5UI/BlendShape 셰이더")]
    public Shader blendShapeShader;

    [Header("선택: 도형 스프라이트 (비워두면 흰색 사각형으로 테스트)")]
    public Sprite shapeSprite;

    void OnEnable()
    {
        if (transform.childCount == 0)
        {
            BuildScene();
        }
    }

    [ContextMenu("Rebuild Test Scene")]
    void BuildScene()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            var child = transform.GetChild(i).gameObject;
#if UNITY_EDITOR
            if (!Application.isPlaying) DestroyImmediate(child);
            else Destroy(child);
#else
            Destroy(child);
#endif
        }

        if (blendShapeShader == null)
        {
            blendShapeShader = Shader.Find("P5UI/BlendShape");
        }
        if (blendShapeShader == null)
        {
            Debug.LogError("[P5MenuTestSetup] P5UI/BlendShape 셰이더를 찾을 수 없습니다. " +
                            "Shaders/P5_UIBlendShape.shader 가 프로젝트에 있는지, " +
                            "Inspector에 수동으로 할당했는지 확인하세요.");
            return;
        }

        // Canvas
        GameObject canvasGO = new GameObject("P5_TestCanvas",
            typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasGO.transform.SetParent(transform, false);

        Canvas canvas = canvasGO.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;

        CanvasScaler scaler = canvasGO.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280, 720);

        // 빨간 배경 (Persona 5 특유의 레드)
        GameObject bg = new GameObject("Background_Red", typeof(Image));
        bg.transform.SetParent(canvasGO.transform, false);
        Image bgImg = bg.GetComponent<Image>();
        bgImg.color = new Color(0.85f, 0.05f, 0.05f);
        RectTransform bgRt = bg.GetComponent<RectTransform>();
        bgRt.anchorMin = Vector2.zero;
        bgRt.anchorMax = Vector2.one;
        bgRt.offsetMin = Vector2.zero;
        bgRt.offsetMax = Vector2.zero;

        // 메뉴 아이템 하나 (도형 2개 겹침)
        GameObject item = new GameObject("MenuItem_Test", typeof(RectTransform));
        item.transform.SetParent(canvasGO.transform, false);
        RectTransform itemRt = item.GetComponent<RectTransform>();
        itemRt.sizeDelta = new Vector2(300, 120);
        itemRt.anchoredPosition = Vector2.zero;

        // 시안 도형: mix-blend-mode: screen 재현
        // Blend One OneMinusSrcColor  == CSS screen
        CreateShape(itemRt, "Shape_Cyan_Screen", new Vector2(10, 10),
            new Color(0f, 1f, 1f, 1f),
            UnityEngine.Rendering.BlendOp.Add,
            UnityEngine.Rendering.BlendMode.One,
            UnityEngine.Rendering.BlendMode.OneMinusSrcColor);

        // 빨간 도형: mix-blend-mode: darken 재현
        // BlendOp Min, Blend One One == CSS darken (채널별 min)
        CreateShape(itemRt, "Shape_Red_Darken", new Vector2(-10, -6),
            new Color(1f, 0f, 0f, 0.8f),
            UnityEngine.Rendering.BlendOp.Min,
            UnityEngine.Rendering.BlendMode.One,
            UnityEngine.Rendering.BlendMode.One);

        Debug.Log("[P5MenuTestSetup] 테스트 씬 구성 완료. " +
                  "Scene 뷰 툴바에서 'Animated Materials'를 켜면 Play 없이 젤리 애니메이션이 보입니다.");
    }

    void CreateShape(RectTransform parent, string name, Vector2 offset, Color color,
        UnityEngine.Rendering.BlendOp op,
        UnityEngine.Rendering.BlendMode src,
        UnityEngine.Rendering.BlendMode dst)
    {
        GameObject go = new GameObject(name, typeof(Image));
        go.transform.SetParent(parent, false);

        Image img = go.GetComponent<Image>();
        img.sprite = shapeSprite; // null이면 기본 흰 사각형으로 렌더됨 (테스트용으로 충분)
        img.color = color;
        img.raycastTarget = false;

        RectTransform rt = go.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(220, 70);
        rt.anchoredPosition = offset;

        Material mat = new Material(blendShapeShader);
        mat.SetFloat("_BlendOp", (float)op);
        mat.SetFloat("_SrcBlend", (float)src);
        mat.SetFloat("_DstBlend", (float)dst);
        mat.SetFloat("_SepiaAmount", 0.5f);
        mat.SetFloat("_Saturation", 3f);
        mat.SetFloat("_JellyOn", 1f);
        mat.SetFloat("_JellySpeed", 2f);
        mat.SetFloat("_SkewAmount", 20f);
        mat.SetFloat("_WobbleAmount", 4f);

        img.material = mat;
    }
}
