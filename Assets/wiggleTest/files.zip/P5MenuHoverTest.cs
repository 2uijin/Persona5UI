using UnityEngine;
using UnityEngine.EventSystems;

// 마우스 호버 시 shape-wrapper가 기울어지는 CSS :hover 효과 테스트용.
// EventSystem 인터랙션이 필요하므로 Play 모드에서만 동작합니다.
// (셰이더/블렌드/젤리 자체는 P5MenuTestSetup만으로 에디트 모드에서 확인 가능)
public class P5MenuHoverTest : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Tooltip("회전시킬 도형 wrapper (shape-wrapper 역할)")]
    public RectTransform shapeWrapper;

    [Tooltip("CSS :nth-child(even) 처럼 짝수 아이템은 반대 방향으로 회전")]
    public bool isEvenItem = false;

    public float oddTiltAngle = -6f;
    public float evenTiltAngle = 11f;
    public float tweenSpeed = 12f;

    float targetAngle = 0f;

    void Update()
    {
        if (shapeWrapper == null) return;

        float current = shapeWrapper.localEulerAngles.z;
        if (current > 180f) current -= 360f;

        float next = Mathf.LerpAngle(current, targetAngle, Time.deltaTime * tweenSpeed);
        shapeWrapper.localRotation = Quaternion.Euler(0, 0, next);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        targetAngle = isEvenItem ? evenTiltAngle : oddTiltAngle;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        targetAngle = 0f;
    }
}
