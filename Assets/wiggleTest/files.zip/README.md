# Persona 5 Menu Effect — Unity URP 테스트 키트

## 파일 구성
```
Shaders/P5_UIBlendShape.shader   # 블렌드모드 + 세피아/채도 + 젤리 왜곡 UI 셰이더
Scripts/P5MenuTestSetup.cs       # 에디트 모드에서 Scene 뷰에 자동으로 테스트 화면 구성
Scripts/P5MenuHoverTest.cs       # 호버 시 기울어지는 인터랙션 (Play 모드 필요)
```

## 설치
1. 세 파일을 프로젝트의 `Assets` 아래 아무 곳에나 복사 (예: `Assets/P5UIKit/`).
   `.shader`는 `Shaders` 폴더, `.cs`는 `Scripts` 폴더에 있어도 되고 섞여 있어도 무관합니다.
2. Unity가 자동으로 컴파일할 때까지 기다립니다.

## Scene 뷰에서 바로 확인하기 (Play 불필요)
1. Hierarchy에서 빈 GameObject 생성 → 이름을 `P5_TestRig` 등으로 지정
2. `P5MenuTestSetup` 컴포넌트를 추가
3. `Blend Shape Shader` 필드가 비어 있으면 자동으로 `P5UI/BlendShape`를 찾습니다.
   못 찾으면 `Assets/.../P5_UIBlendShape.shader`를 직접 드래그해서 할당하세요.
4. 컴포넌트가 `OnEnable`에서 자동으로 Canvas + 빨간 배경 + 시안/빨강 도형 2개를 생성합니다.
5. **Scene 뷰 상단 툴바의 "Animated Materials" 아이콘(재생 버튼 모양)을 켜세요.**
   이걸 켜야 Play 모드 없이도 `_Time` 기반 젤리 왜곡 애니메이션이 Scene 뷰에서 재생됩니다.
6. 값을 바꾸고 싶으면 GameObject를 Inspector에서 확인하거나,
   컴포넌트 우클릭(⋮) → **Rebuild Test Scene** 으로 재생성하세요.

## 블렌드 모드 프리셋 (CSS mix-blend-mode 대응표)

| CSS 값     | BlendOp | Src Blend | Dst Blend           |
|-----------|---------|-----------|---------------------|
| `screen`  | Add     | One       | OneMinusSrcColor     |
| `darken`  | Min     | One       | One                  |
| `multiply`| Add     | DstColor  | Zero                 |
| 일반(알파블렌드) | Add | SrcAlpha  | OneMinusSrcAlpha     |

`P5MenuTestSetup.CreateShape()`가 이미 시안=screen, 빨강=darken으로 세팅되어 있습니다.
Multiply가 필요하면 같은 패턴으로 머티리얼을 하나 더 만들면 됩니다.

## 셰이더 파라미터
- `_SepiaAmount` (0~1): CSS `filter: sepia(50%)` 대응, 기본 0.5
- `_Saturation` (0~5): CSS `filter: saturate(3)` 대응, 기본 3
- `_JellyOn` / `_JellySpeed` / `_SkewAmount` / `_WobbleAmount`: CSS `@keyframes jelly` 대응
  버텍스 셰이더에서 sin파 기반으로 skew + wobble을 줌

## 호버 인터랙션 테스트 (Play 모드 필요)
1. 실제 메뉴 아이템 GameObject에 `P5MenuHoverTest` 추가
2. `Shape Wrapper` 필드에 회전시킬 RectTransform 연결
3. 짝수 번째 아이템은 `Is Even Item` 체크 (CSS `:nth-child(even)`과 동일하게 반대 방향 회전)
4. Play 모드 진입 후 Game 뷰에서 마우스를 올려 확인 (EventSystem이 씬에 있어야 함 —
   `GraphicRaycaster`가 붙은 Canvas가 있으면 EventSystem은 자동 요청됩니다)

## 다음 단계 제안
- 지금은 흰 사각형(Image 기본 스프라이트)으로 테스트하지만, 실제 프로젝트에서는
  `Shape Sprite` 필드에 원본 SVG를 PNG로 구운 스프라이트(알파 채널 포함)를 넣으면
  원본과 동일한 불규칙 폴리곤 실루엣이 나옵니다.
- 진짜 배경(빨간 배경 외에 다른 UI가 뒤에 있는 경우)까지 정확히 CSS와 동일하게
  블렌드하려면, Canvas를 별도 RenderTexture로 렌더링 후 URP Custom Renderer Feature에서
  합성하는 방식이 더 정확합니다. 지금 셰이더는 하드웨어 블렌드 근사치이며,
  대부분의 UI 뒤 배경이 단색/그라디언트라면 육안상 차이가 거의 없습니다.
